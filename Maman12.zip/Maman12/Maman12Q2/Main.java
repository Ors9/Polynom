
public class Main {

	public static void main(String[] args) {
		// Create an instance of EmployeeManager
		EmployeeManager manager = new EmployeeManager();

		// Print employee details with salaries also PieceWorker
		manager.printArrayOfEmployees();

	}

}
